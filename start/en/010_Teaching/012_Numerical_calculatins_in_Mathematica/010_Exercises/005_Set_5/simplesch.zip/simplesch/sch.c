#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <complex.h>
#include <string.h>

struct objStateDomain
{
	int size;
	double dt;
	double dxy;
	double complex * wave_new;
	double complex * wave_old;
	double * mask;
};

typedef struct objStateDomain stateDomain;

int stateDomain_destruct(stateDomain * this)
{
	free(this -> wave_new);
	free(this -> wave_old);
	free(this -> mask);

	return 1;
}

stateDomain * stateDomain_new(char * path_to_mask)
{
	stateDomain * res = malloc(sizeof(stateDomain));

	//
	FILE * mask_file = fopen(path_to_mask , "r");
	fscanf(mask_file , "%lf" , &(res -> dt));
	fscanf(mask_file , "%lf" , &(res -> dxy));
	fscanf(mask_file , "%d" , &(res -> size));

	res -> mask = malloc((res -> size) * (res -> size) * sizeof(double));
	for(int i = 0 ; i < (res -> size) * (res -> size) ; i++)
	{
		fscanf(mask_file , "%lf" , (res -> mask) + i);
	}

	res -> wave_new = malloc((res -> size) * (res -> size) * sizeof(double complex));
	res -> wave_old = malloc((res -> size) * (res -> size) * sizeof(double complex));
	for(int i = 0 ; i < (res -> size) * (res -> size) ; i++)
	{
		double re;
		fscanf(mask_file , "%lf" , &re);
		(res -> wave_new)[i] = 0.0;
		(res -> wave_old)[i] = re;
	}

	for(int i = 0 ; i < (res -> size) * (res -> size) ; i++)
	{
		double im;
		fscanf(mask_file , "%lf" , &im);
		(res -> wave_new)[i] += 0.0;
		(res -> wave_old)[i] += I * im;
	}

	fclose(mask_file);
	//
	
	return res;
}

int stateDomain_show(const stateDomain * this)
{
	printf("size : %d\n" , this -> size);
	printf("dt : %lf\n" , this -> dt);
	printf("dxy : %lf\n" , this -> dxy);

	return 1;
}

int stateDomain_save(const stateDomain * this , char * path)
{
	//
	FILE * f = fopen(path , "w");
	fprintf(f , "%lf\n" , this -> dt);
	fprintf(f , "%lf\n" , this -> dxy);
	fprintf(f , "%d\n" , this -> size);
	for(int r = 0 ; r < this -> size ; r++)
	{
		for(int c = 0 ; c < this -> size ; c++)
		{
			fprintf(f , "%lf " , (this -> mask)[r * (this -> size) + c]);
		}
		fprintf(f , "\n");
	}
	for(int r = 0 ; r < this -> size ; r++)
	{
		for(int c = 0 ; c < this -> size ; c++)
		{
			fprintf(f , "%lf " , creal((this -> wave_old)[r * (this -> size) + c]));
		}
		fprintf(f , "\n");
	}
	for(int r = 0 ; r < this -> size ; r++)
	{
		for(int c = 0 ; c < this -> size ; c++)
		{
			fprintf(f , "%lf " , cimag((this -> wave_old)[r * (this -> size) + c]));
		}
		fprintf(f , "\n");
	}
	fclose(f);
	//
}

int mod(int a , int b)
{
	int m = a % b;
	return (m < 0) ? m + b : m;
}

int stateDomain_iterate(stateDomain * this)
{
	for(int r = 0 ; r < this -> size ; r++)
	{
		for(int c = 0 ; c < this -> size ; c++)
		{
			double complex lpl = 0.0;
			lpl += (this -> wave_old)[mod((r + 1) , (this -> size)) * (this -> size) + c];
			lpl += (this -> wave_old)[mod((r - 1) , (this -> size)) * (this -> size) + c];
			lpl += (this -> wave_old)[r * (this -> size) + mod((c + 1) , (this -> size))];
			lpl += (this -> wave_old)[r * (this -> size) + mod((c - 1) , (this -> size))];
			lpl += -4.0 * (this -> wave_old)[r * (this -> size) + c];
			lpl /= (this -> dxy) * (this -> dxy); 

			(this -> wave_new)[r * (this -> size) + c] = \
				(this -> wave_old)[r * (this -> size) + c] + \
					0.5 * I * (this -> dt) * lpl;
			(this -> wave_new)[r * (this -> size) + c] *= (this -> mask)[r * (this -> size) + c];
		}
	}

	for(int r = 0 ; r < this -> size ; r++)
	{
		for(int c = 0 ; c < this -> size ; c++)
		{
			(this -> wave_old)[r * (this -> size) + c] = \
				(this -> wave_new)[r * (this -> size) + c];
		}
	}
}

int main(int argc , char **argv) 
{

	stateDomain * workingDomain = NULL;
	char * outputFile = NULL;
	int iterations = 0;

	int option , index;
	opterr = 0;

	while((option = getopt(argc , argv , "ho:m:i:")) != -1)
	{
		switch(option)
		{
			case 'h':
				printf(
					"usage: [-h] [-o output_path] [-m mask_path] [-i number_of_iterations]\n"
				    "   output_path : path to output file\n"
				    "   input_path : path to input file\n"
				    "   number_of_iterations : number of iterations of the Euler algorithm\n"
				    "\n"
					"Starting with the wave function on a 2D plane and potential defined in the input_path\n"
					"attempts to calculate the evolution of the wave function using the\n"
					"basic Euler method. The wave function is discretized on a regular 2D lattice.\n"
					"The potential is either 0 or infinity. The result after a number of time steps\n"
					"is saved to output_path. Periodic boundary conditions are used on lattice edges.\n"
					"\n"
					"Input and output files have the same format.\n"
					"They are text files with the following elements\n"
					"(<...> contain a description of each element,\n"
					"each element is a single number, a space separated list of numbers\n"
					"or an array of numbers with rows separated by new lines and columns\n"
					"separated by spaces):\n"
					"<dt (floating point, eg 0.000001) : step size for time in the Euler method>\n"
					"<dxy (floating point, eg 0.01) : lattice spacing>\n"
					"<size (positive integer, eg 100) : the Schrodinger equation will be solved on a size x size lattice>\n"
					"<size x size array (1. or 0.) : the value 0 means that the corresponding lattice point has infinite potential>\n"
					"<size x size array (floating point) : real part of the wave function at corresponding lattice points>\n"
					"<size x size array (floating point) : imaginary part of the wave function at corresponding lattice points>\n"
					"\n"
					"NOTE: In this example we are not out for precision but simplicity. The method is primitive\n"
					"but should work reasonably well given the right parameters.\n"
					);
				// TODO add more about the format for input, output 
				return 0;
				break;
			case 'o':
				outputFile = strdup(optarg);
				break;
			case 'i':
				sscanf(optarg , "%d" , &iterations);
				break;
			case 'm':
				workingDomain = stateDomain_new(optarg);
				break;
			default:
				printf("option not recognized: %c\n", optopt);
				break;
		}
	}

	if(NULL == workingDomain)
	{
		fprintf(stderr , "Error. Path to mask not in arguments. Exiting.\n");
		return 1;
	}
	if(NULL == outputFile)
	{
		fprintf(stderr , "Error. Path to output file not in arguments. Exiting.\n");
		return 1;
	}
	if(0 == iterations)
	{
		fprintf(stderr , "Error. Iterations not in arguments. Exiting.\n");
		return 1;
	}
	stateDomain_show(workingDomain);
	for(int i = 0 ; i < iterations ; i++)
	{
		stateDomain_iterate(workingDomain);
	}
	stateDomain_save(workingDomain , outputFile);
	stateDomain_destruct(workingDomain);
}
