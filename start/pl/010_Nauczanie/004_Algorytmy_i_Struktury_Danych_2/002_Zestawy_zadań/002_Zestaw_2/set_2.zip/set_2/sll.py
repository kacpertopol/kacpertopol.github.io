from rec import recorder
import copy

N = 3

def hf(x):
    if not isinstance(x , int):
        raise ValueError("Expecting integer.")
    return x % N

def to_str_nice(l , p , c , tab = 0 , spaces = 13 , p_comment = " <- previous" , c_comment = " <- current"):
    description = ""
    if l == p:
        description = p_comment
    if l == c:
        description = c_comment
    res = []
    if len(l) == 0:
        return "[]"
    elif len(l) == 1:
        return " " * tab + "[" + " \u2577 ]".rjust(spaces - 1) + description + "\n" + \
                to_str_nice(l[0] , p , c , tab = tab + spaces , spaces = spaces , p_comment = p_comment , c_comment = c_comment)
    elif len(l) == 2:
        if l[1] is None:
            return " " * (tab - 3) + "\u2570\u2500\u2500" + "[" + (str(l[0]) + ", x ]").rjust(spaces - 1) + description + "\n"
        else:
            return " " * (tab - 3) + "\u2570\u2500\u2500" + "[" + (str(l[0]) + ", \u2577 ]").rjust(spaces - 1) + description + "\n" + \
                    to_str_nice(l[1] , p , c , tab = tab + 13 , spaces = spaces , p_comment = p_comment , c_comment = c_comment)

def add(l_b , x):
    """
    Adds x to set l_b. Modifies l_b.
    """
    r = recorder(
            {
                "bucket" : lambda b : "bucket : " + str(b) ,
                ("l_b" , "previous" , "current") : lambda ll_b , p , c : "\n".join(str(i) + " : \n" + to_str_nice(ll_b[i] , p , c) for i in range(len(ll_b))) 
             } , raise_error = False)
    with r:
        r.record(step = "INITIAL STATE")
        bucket = hf(x)
        r.record(step = "CHOSE BUCKET")
        l = l_b[bucket]
        if len(l) == 0:
            new = [x , None]
            l.append(new)
            r.record(step = "ADDING FIRST ELEMENT")
        else:
            previous = l
            current = l[0]
            while True:
                r.record(step = "STARTING SEARCH")
                val , nxt = current
                if val >= x:
                    new = [x ,  current]
                    r.record(step = "INSERTING NEW")
                    if len(previous) == 1:
                        previous[0] = new
                        r.record(step = "UPDATING STRUCTURE")
                    else:
                        previous[1] = new
                        r.record(step = "UPDATING STRUCTURE")
                    break
                if nxt is None:
                    r.record(step = "INSERTING NEW ON TOP")
                    new = [x ,  None]
                    current[1] = new
                    r.record(step = "UPDATING STRUCTURE")
                    break
                previous = current
                current = nxt
    return r

def remove(l_b , x):
    """
    Removes x from set l_b. Modifies l_b.
    """
    r = recorder(
            {
                "bucket" : lambda b : "bucket : " + str(b) ,
                ("l_b" , "previous" , "current") : lambda ll_b , p , c : "\n".join(str(i) + " : \n" + to_str_nice(ll_b[i] , p , c) for i in range(len(ll_b))) 
             } , raise_error = False)
    with r:
        r.record(step = "INITIAL STATE")
        bucket = hf(x)
        r.record(step = "CHOSE BUCKET")
        l = l_b[bucket]
        if len(l) > 0:
            previous = l
            current = l[0]
            while True:
                r.record(step = "STARTING SEARCH")
                val , nxt = current
                if val == x:
                    r.record(step = "FOUND " + str(x))
                    if len(previous) == 1:
                        previous[0] = nxt
                    else:
                        previous[1] = nxt
                    r.record(step = "UPDATED STRUCTURE")
                    break
                if val > x:
                    break
                if nxt is None:
                    break
                previous = current
                current = nxt
    return r

def intersection(l1_b , l2_b):
    """
    Calculates the intersection of sets l1 and l2. Returns new set.
    """
    r = recorder(
            {
                "bucket" : lambda b : "bucket : " + str(b) ,
                ("l1_b" , "previous1" , "current1") : lambda ll_b , p , c : "l1_b : \n" + "\n".join(str(i) + " : \n" + to_str_nice(ll_b[i] , p , c) for i in range(len(ll_b))) ,
                ("l2_b" , "previous2" , "current2") : lambda ll_b , p , c : "l2_b : \n" + "\n".join(str(i) + " : \n" + to_str_nice(ll_b[i] , p , c) for i in range(len(ll_b))) ,
                ("l1l2_b" , "previous" , "current") : lambda ll_b , p , c : "l1l2_b : \n" + "\n".join(str(i) + " : \n" + to_str_nice(ll_b[i] , p , c) for i in range(len(ll_b))) 
             } , raise_error = False)
    with r:
        l1l2_b = make_empty()
        r.record(step = "INITIAL STATE")
        for bucket in range(N): 
            r.record(step = "CHOSE BUCKET")
            l1 = l1_b[bucket]
            l2 = l2_b[bucket]
            top = None
            if len(l1) == 0:
                l1l2_b[bucket] = []
                r.record(step = "FINISHED WITH BUCKET")
            elif len(l2) == 0:
                l1l2_b[bucket] = []
                r.record(step = "FINISHED WITH BUCKET")
            else:
                previous1 = l1
                current1 = l1[0]
                previous2 = l2
                current2 = l2[0]
                while True:
                    r.record(step = "STARTING SEARCH")
                    val1 , nxt1 = current1
                    val2 , nxt2 = current2
                    if val1 == val2:
                        r.record(step = str(val1) + " IN BOTH SETS")
                        new = [val1 , None]
                        if top == None:
                            l1l2_b[bucket].append(new)
                            top = new
                        else:
                            top[1] = new
                            top = new
                        r.record(step = "ADDING TO NEW LIST")
                    if nxt1 is not None and val2 > val1:
                        previous1 = current1
                        current1 = nxt1
                    elif nxt2 is not None:
                        previous2 = current2
                        current2 = nxt2
                    else:
                        r.record(step = "REACHED END")
                        break

        r.record(step = "FINISHED")
    return r , l1l2_b

def make_empty():
    return [[] for _ in range(N)]

if __name__ == "__main__":
    a = make_empty()
    add(a , 12)
    add(a , 32)
    add(a , 8)
    add(a , 15)
    add(a , 100)
    add(a , 5)
    r = add(a , 11)
    r.play(title = "adding 11")

    r = remove(a , 15)
    r.play(title = "removing 15")

    b = make_empty()
    add(b , 31)
    add(b , 22)
    add(b , 10)
    add(b , 11)
    add(b , 5)
    r , _ = intersection(a , b)
    r.play(title = "calculating intersection")


