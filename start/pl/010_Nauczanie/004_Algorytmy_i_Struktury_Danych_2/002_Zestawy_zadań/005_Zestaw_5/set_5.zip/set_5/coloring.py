from rec import recorder

def vis_cl(cl , gr , node , neighbour_colors):
    result = []
    result.append("graph:")
    for n in gr:
        if n == node:
            result.append("* " + str(n) + " : " + str(gr[n]))
        else:
            result.append("  " + str(n) + " : " + str(gr[n]))
    result.append("node colors:")
    for n in cl:
        if n == node:
            result.append("* " + str(n) + " : " + str(cl[n]))
        else:
            result.append("  " + str(n) + " : " + str(cl[n]))

    if neighbour_colors is None:
        result.append("neighbour colors: ")
    elif len(neighbour_colors) > 0:
        result.append("neighbour colors: " + str(neighbour_colors))
    else:
        result.append("neighbour colors: {}")

    return "\n".join(result) 

def color_graph(gr , ordering = lambda x : x):
    keys = None
    if isinstance(ordering , list):
        keys = ordering
    else:
        keys = ordering(gr.keys())
    cl = dict()
    node = None
    n_colors = None

    r = recorder({("cl" , "gr" , "node" , "n_colors") : vis_cl})
    with r:
        for k in keys:
            cl[k] = None
        r.record(step = "INITIAL STATE")

        for node in keys:
            neighbours = gr[node]
            n_colors = set()
            r.record(step = "CHECKING NODE " + str(node))
            for n in neighbours:
                if cl[n] is not None:
                    n_colors.add(cl[n])

            r.record(step = "CHECKED NEIGHBOUR COLORS")
            node_color = None
            for c in range(len(keys)):
                if c not in n_colors:
                    node_color = c
                    break
            cl[node] = node_color
            r.record(step = "DONE WITH NODE " + str(node))

    return r , cl

if __name__ == "__main__":

    graph = {
                0 : {2} ,
                1 : {2} ,
                2 : {0 , 1 , 3 , 4} ,
                3 : {2 , 4} ,
                4 : {2 , 3}
            }

#    r , _ = color_graph(graph)
#    r.play()
    
#    r , _ = color_graph(graph , ordering = lambda x : list(reversed(x)))
#    r.play()

    graph1 = {
                1 : {6 , 7 , 8} ,
                2 : {5 , 7 , 8} ,
                3 : {5 , 6 , 8} ,
                4 : {5 , 6 , 7} ,
                5 : {2 , 3 , 4} ,
                6 : {1 , 3 , 4} ,
                7 : {1 , 2 , 4} ,
                8 : {1 , 2 , 3}
            }
       
#    r , _ = color_graph(graph1)
#    r.play()
    
    r , _ = color_graph(graph1 , ordering = [1 , 5 , 2 , 6 , 3 , 7 , 4 , 8])
    r.play()

