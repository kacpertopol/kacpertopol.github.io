# sauce : https://www.geeksforgeeks.org/dsa/binary-heap/

import math

from rec import recorder

def vis_bh(bh , a , b , spaces = 2):
    n = spaces + 2
    result = []
    levels = math.ceil(math.log2(len(bh) + 1))
    c = 0
    for i in range(levels):
        d = c + 2**i
        elements = bh[c : d]
        jn = " " * (n * 2**(levels - 1 - i) - n)
        result.append(
                jn.join(
                    list(
                        map(
                            lambda x : \
                                ("(" + str(x) + ")").ljust(n) if x == a else \
                                ("[" + str(x) + "]").ljust(n) if x == b else \
                                " " + str(x).ljust(n - 1), 
                            elements))))
        c = d
    return "\n".join(result)

# HELPER FUNCTIONS

def left_child(i):
    return 2 * i + 1

def right_child(i):
    return 2 * i + 2

def parent(i):
    return (i - 1) // 2

def make_empty():
    return []

def insert(bh , e):
    a = None
    b = None
    r = recorder({("bh" , "a" , "b") : vis_bh})
    with r:
        r.record(step = "INITIAL STATE OF INSERT " + str(e))
        bh.append(e)
        r.record(step = "ADDED ELEMENT TO THE LAST LEVEL")
        i = len(bh) - 1
        while True:
            if i <= 0:
                break
            a , b = bh[parent(i)] , bh[i]
            r.record(step = "COMPARING WITH PARENT")
            if a > b:
                break
            bh[parent(i)] , bh[i] = b , a
            i = parent(i)
            r.record(step = "SWAPPING")
        a , b = None , None
        r.record(step = "FINISHED")
        return r

def remove_max(bh):
    a = None
    b = None
    rr = recorder({("bh" , "a" , "b") : vis_bh})
    with rr:
        rr.record(step = "INITIAL STATE of REMOVE_MAX")
        if len(bh) == 0:
            rr.record(step = "EMPTY HEAP")
            return rr , None
        elif len(bh) == 1:
            largest = bh.pop()
            rr.record(step = "ONLY ONE ELEMENT IN HEAP")
            return rr , largest
        else:
            largest = bh[0]
            end = bh.pop()
            bh[0] = end
            rr.record(step = "LAST ELEMENT TO ROOT")
            i = 0
            while True:
                largest = i
                l , r , n = left_child(i) , right_child(i) , len(bh)
                if l < n and bh[l] > bh[largest]: 
                    largest = l
                if r < n and bh[r] > bh[largest]: 
                    largest = r
                if largest == i:
                    a , b = None , None
                    rr.record(step = "FINISHED")
                    break
                else:
                    a , b = bh[i] , bh[largest]
                    rr.record(step = "SWAPPING")
                    bh[i] , bh[largest] = b , a
                i = largest
            return rr , largest

if __name__ == "__main__":

    h = make_empty()

    for i in range(35):
        insert(h , 2 * i)

    r = insert(h , 78)
    r.play()

    r , _ = remove_max(h)
    r.play()

    h1 = make_empty()
    r , _ = remove_max(h1)
    r.play()

    h2 = make_empty()
    insert(h2 , 1)
    r , _ = remove_max(h2)
    r.play()
