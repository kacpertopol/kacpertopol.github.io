# sauce : https://bradfieldcs.com/algos/graphs/word-ladder/
from collections import deque

from rec import recorder

simple_graph = {
    'A': {'B', 'D'},
    'B': {'C', 'D'},
    'C': set(),
    'D': {'E'},
    'E': {'B', 'F'},
    'F': {'C'}
}


def vis(vert , graph , path , visited , queue):
    res = []
    res.append("GRAPH:")
    for v in graph:
        if v == vert:
            res.append("* " + v + " -> " + str(graph[v]))
        else:
            res.append("  " + v + " -> " + str(graph[v]))
    res.append("VISITED: " + str(visited))
    res.append("PATH: " + str(path))
    res.append("QUEUE:")
    for p in queue:
        res.append("  " + str(p))
    return "\n".join(res)

def traverse(graph, starting_vertex):
    visited = set()
    queue = deque([[starting_vertex]])

    vert = starting_vertex
    path = None

    r = recorder({("vert" , "graph" , "path" , "visited" , "queue") : vis})

    r.record(step = "initial state")

    result = []

    while queue:
        path = queue.popleft()
        vertex = path[-1]
        vert = vertex

        r.record(step = "popleft")

        result.append((vertex , path))
        
        for neighbor in graph[vertex] - visited:
            vert = neighbor
            r.record(step = "starting " + str(neighbor) + " from " + str(graph[vertex] - visited))
            visited.add(neighbor)
            queue.append(path + [neighbor])
            r.record(step = "done with " + str(neighbor))

    return result , r

_ , r = traverse(simple_graph, 'A')

r.play()

