# sauce : https://bradfieldcs.com/algos/graphs/depth-first-search/
from collections import defaultdict
from copy import deepcopy

simple_graph = {
    'A': ['B', 'D'],
    'B': ['C', 'D'],
    'C': [],
    'D': ['E'],
    'E': ['B', 'F'],
    'F': ['C']
}

from rec import recorder

current = None
counter_ = [123]

def depth_first_search(graph, starting_vertex):

    visited = set()
    counter = [0]
    counter_[0] = counter[0]
    traversal_times = defaultdict(dict)

    def vis(vv , c , g , visited , gtt):
        gtt = deepcopy(gtt)
        #with open("log" , "a") as f:
        #    f.write("cv" + str(vv) + "\n")
        res = []
        res.append("COUNTER: " + str(c[0]))
        if len(visited) == 0:
            res.append("VISITED:")
        else:
            res.append("VISITED: " + str(visited))
        res.append("GRAPH:")
        for v in g:
            if vv is not None and v == vv:
                res.append("* " + v + " -> " + str(g[v]))
            else:
                res.append("  " + v + " -> " + str(g[v]))

        res.append("TRAVERSAL TIMES:")
        for v in gtt:
            if vv is not None and v == vv:
                res.append("* " + v + " : " + str(gtt[v]))
            else:
                res.append("  " + v + " : " + str(gtt[v]))
        return "\n".join(res)

    r = recorder({("current" , "counter_" , "graph" , "visited" , "traversal_times") : vis})

    with r:
        def traverse(vertex):
            global current , counter_
            current = vertex
            r.record()
            visited.add(vertex)
            counter[0] += 1
            counter_[0] = counter[0]
            traversal_times[vertex]['discovery'] = counter[0]
            r.record()

            for next_vertex in graph[vertex]:
                if next_vertex not in visited:
                    traverse(next_vertex)

            counter[0] += 1
            counter_[0] = counter[0]
            traversal_times[vertex]['finish'] = counter[0]
            r.record()

        # in this case start with just one vertex, but we could equally
        # dfs from all_vertices to produce a dfs forest

        traverse(starting_vertex)
    return r , traversal_times

r , traversal_times = depth_first_search(simple_graph, 'A')

r.play()
# =>
# {
#     'A': {
#         'discovery': 1,
#         'finish': 12
#     },
#     'B': {
#         'discovery': 2,
#         'finish': 11
#     },
#     'C': {
#         'discovery': 3,
#         'finish': 4
#     },
#     'D': {
#         'discovery': 5,
#         'finish': 10
#     },
#     'E': {
#         'discovery': 6,
#         'finish': 9
#     },
#     'F': {
#         'discovery': 7,
#         'finish': 8
#     }
# }
