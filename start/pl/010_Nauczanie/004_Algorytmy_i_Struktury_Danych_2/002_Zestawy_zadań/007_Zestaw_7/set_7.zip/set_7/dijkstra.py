# sauce : https://bradfieldcs.com/algos/graphs/dijkstras-algorithm/

from rec import recorder

def vis(graph , vert , neigh , distances , heap):
    res = []
    res.append("GRAPH:")
    for v in graph:
        if v == vert:
            res.append("* " + v + " -> " + str(graph[v]))
        elif v == neigh:
            res.append("@ " + v + " -> " + str(graph[v]))
        else:
            res.append("  " + v + " -> " + str(graph[v]))
    res.append("DISTANCES: " + str(distances))
    res.append("HEAP: " + str(heap))
    return "\n".join(res)

import heapq

def calculate_distances(graph, starting_vertex):
    distances = {vertex: float('infinity') for vertex in graph}
    distances[starting_vertex] = 0

    vert = starting_vertex
    neigh = None
 
    pq = [(0, starting_vertex)]
    # heapify not necessary, this is the smallest element
    
    r = recorder({("graph" , "vert" , "neigh" , "distances" , "pq") : vis})
    r.record(step = "initial state")
    
    while len(pq) > 0:
        r.record(step = "before pop")
        
        current_distance, current_vertex = heapq.heappop(pq)

        vert = current_vertex
        neigh = None

        r.record(step = "after pop")

        # Nodes can get added to the priority queue multiple times. We only
        # process a vertex the first time we remove it from the priority queue.
        if current_distance > distances[current_vertex]:
            continue

        for neighbor, weight in graph[current_vertex].items():
            neigh = neighbor

            distance = current_distance + weight

            # Only consider this new path if it's better than any path we've
            # already found.
            if distance < distances[neighbor]:
                distances[neighbor] = distance
                heapq.heappush(pq, (distance, neighbor))

                r.record(step = "update distances")
            else:
                r.record(step = "skipping to next neighbor")

    return r , distances


example_graph = {
    'U': {'V': 2, 'W': 5, 'X': 1},
    'V': {'U': 2, 'X': 2, 'W': 3},
    'W': {'V': 3, 'U': 5, 'X': 3, 'Y': 1, 'Z': 5},
    'X': {'U': 1, 'V': 2, 'W': 3, 'Y': 1},
    'Y': {'X': 1, 'W': 1, 'Z': 1},
    'Z': {'W': 5, 'Y': 1},
}

r , dist = calculate_distances(example_graph, 'U')

r.play()
