#!/usr/bin/env python3

# sauce 1 : https://realpython.com/python-csv/
# sauce 2 : https://matplotlib.org/stable/tutorials/pyplot.html

import csv
import matplotlib.pyplot as plt

names = []
values = []

with open("/home/kacper/Documents/temp_16-01-2024/category.csv") as csv_file:
    csv_reader = csv.reader(csv_file , delimiter = ',')
    for name , value in csv_reader:
        names.append(name)
        values.append(float(value))

plt.xlabel("names")
plt.ylabel("values")
plt.title("names and values")
plt.bar(names , values)
plt.show()
