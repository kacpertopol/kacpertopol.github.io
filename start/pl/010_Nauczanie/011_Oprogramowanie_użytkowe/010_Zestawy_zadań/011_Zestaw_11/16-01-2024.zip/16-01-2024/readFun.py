#!/usr/bin/env python3

# sauce 1 : https://realpython.com/python-csv/
# sauce 2 : https://matplotlib.org/stable/tutorials/pyplot.html
# sauce 3 : https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.curve_fit.html

import csv
import matplotlib.pyplot as plt

import numpy as np

x = []
y = []

with open("/home/kacper/Documents/temp_16-01-2024/fun.csv") as csv_file:
    csv_reader = csv.reader(csv_file , delimiter = ',')
    for xval , yval in csv_reader:
        x.append(float(xval))
        y.append(float(yval))

plt.xlabel("x")
plt.ylabel("sin(x)")
plt.title("function")
plt.plot(x , y)
plt.show()

xnp = np.array(x)
ynp = np.array(y)
ynp1 = xnp * ynp

plt.xlabel("x")
plt.ylabel("x sin(x)")
plt.title("function")
plt.plot(xnp , ynp1)
plt.show()

from scipy.optimize import curve_fit

def fun(x , a , b , c):
    return a * x * np.sin(b * x) + c

popt , pcov = curve_fit(fun , xnp , ynp1)

print("optimal parameters:")
print(popt)
print("covariance matrix:")
print(pcov)
print("standard deviation errors:")
print(np.sqrt(np.diag(pcov)))

plt.xlabel("x")
plt.ylabel("y")
plt.plot(xnp , ynp1 , 'b-' , label = "data")
plt.plot(xnp , fun(xnp , *popt) , 'r-' , label = 'fit: a=%5.3f, b=%5.3f, c=%5.3f' % tuple(popt))
plt.legend()
plt.show()

