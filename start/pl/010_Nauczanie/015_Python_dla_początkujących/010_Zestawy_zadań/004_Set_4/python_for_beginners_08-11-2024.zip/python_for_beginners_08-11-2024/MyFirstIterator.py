class MyFirstIterator:
    def __init__(self , v):
        self.v = v
        self.current = 0
    def __iter__(self):
        return self
    def __next__(self):
        self.current += 1
        if(self.current <= self.v):
            return self.current
        else:
            raise StopIteration

