someImportantValue = 42

class MulBy:
    classValue = 24
    def __init__(self , value):
        self.someObjectValue = value
    def __str__(self):
        return "\ x -> x * " + str(self.someObjectValue)
    def __call__(self , x):
        return x * self.someObjectValue
    def changeValue(self , value):
        self.someObjectValue = value

        
