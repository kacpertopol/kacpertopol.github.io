import sys

print(sys.builtin_module_names)
print(sys.path)
