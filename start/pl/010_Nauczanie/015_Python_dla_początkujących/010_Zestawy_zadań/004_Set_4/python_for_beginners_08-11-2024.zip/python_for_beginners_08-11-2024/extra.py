def fun(stack):
    return stack
def nuf(stack):
    return stack
def foo(stack):
    return stack
def fum(stack):
    return stack
