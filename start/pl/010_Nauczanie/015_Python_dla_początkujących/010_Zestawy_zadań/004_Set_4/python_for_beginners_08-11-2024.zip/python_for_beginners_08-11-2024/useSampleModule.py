#!/usr/bin/env python3

import SampleModule as sm

print(sm.someImportantValue)
