class encoder:
    def __init__(self , key):
        self.key = key
    def __call__(self , plaintext):
        return "".join(reversed(plaintext))

class decoder:
    def __init__(self , key):
        self.key = key
    def __call__(self , ciphertext):
        return "".join(reversed(ciphertext))
