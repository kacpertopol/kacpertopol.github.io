import argparse
import math

def norm(x , y):
    return math.sqrt(x**2 + y**2)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
            prog = "command_line_interface",
            description = """This is a sample command line interface program. 
            Calculated the length of a vector."""
            )
    parser.add_argument("x" , help = "First coordinate of vector." , type = float)
    parser.add_argument("y" , help = "Second coordinate of vector." , type = float)
    parser.add_argument("--path" , "-p" , help = "Path to output file")
    parser.add_argument("--relative" , "-r" , help = "Path to file with point coordinates.")

    args = parser.parse_args()

    x = args.x
    y = args.y

    xr = 0.0
    yr = 0.0

    if args.relative is not None:
        with open(args.relative , "r") as f:
            xr , yr = f.read().split()
            xr = float(xr)
            yr = float(yr)

    result = norm(x - xr , y - yr)

    if args.path is None:
        print(result)
    else:
        #f = open(args.path , "w")
        #try:
        #    f.write(str(result))
        #finally:
        #    f.close()
        with open(args.path , "w") as f:
            f.write(str(result))
