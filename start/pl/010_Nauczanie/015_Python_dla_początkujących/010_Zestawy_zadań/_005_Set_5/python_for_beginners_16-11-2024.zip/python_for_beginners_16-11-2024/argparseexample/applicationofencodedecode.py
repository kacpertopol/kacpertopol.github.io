from notes import encode , decode

print(encode(123 , "Some secret note"))
