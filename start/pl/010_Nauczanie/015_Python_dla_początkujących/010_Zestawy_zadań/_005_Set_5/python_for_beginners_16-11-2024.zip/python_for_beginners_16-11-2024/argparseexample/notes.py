import argparse
import json

def encode(key , plaintext):
    return plaintext

def decode(key , ciphertext):
    return ciphertext

if(__name__ == "__main__"):
    #print("We are in the main program!")
    parser = argparse.ArgumentParser(prog = "notes" , usage = "TODO")
    parser.add_argument("password" , 
            type = int ,
            help = "Secret password, should contain letters, numbers and symbols.")
    parser.add_argument("--print" , "-p" , action = "store_true" , help = "Print all notes.")
    parser.add_argument("--keywords" , "-k" , action = "append" , help = "Add keyword.")
    args = parser.parse_args()

    print("The super secret password is:" , args.password)
    print("Print all notes? : " , args.print)
    keywordset = set(args.keywords)
    print("Keywords : " , args.keywords)
    print("Keyword set : " , keywordset)
