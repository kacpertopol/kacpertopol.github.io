#!/usr/bin/env python3

def encode(key, string):
# sauce: https://stackoverflow.com/questions/2490334/simple-way-to-encode-a-string-according-to-a-password
    encoded_chars = []
    for i in range(len(string)):
        key_c = key[i % len(key)]
        encoded_c = chr(ord(string[i]) + ord(key_c) % 256)
        encoded_chars.append(encoded_c)
    return "".join(encoded_chars)

def decode(key, string):
# sauce: https://stackoverflow.com/questions/2490334/simple-way-to-encode-a-string-according-to-a-password
    encoded_chars = []
    for i in range(len(string)):
        key_c = key[i % len(key)]
        encoded_c = chr(ord(string[i]) - ord(key_c) % 256)
        encoded_chars.append(encoded_c)
    return "".join(encoded_chars)
