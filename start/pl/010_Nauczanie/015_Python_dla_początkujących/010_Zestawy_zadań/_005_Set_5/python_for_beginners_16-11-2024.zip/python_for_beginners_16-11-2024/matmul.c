#include <stdlib.h>
#include <stdio.h>

#define SIZE 1024
#define ITER 4

int main()
{
	/////////////////////////////////////
	// uncomment to allocate on stack: // 
	/////////////////////////////////////
	/*double a[SIZE][SIZE];
	double b[SIZE][SIZE];
	double ab[SIZE][SIZE];*/

	//////////////////////////
	// if on stack comment: //
	//////////////////////////
	/**/
	double **a , **b , **ab;

	a = (double **)malloc(SIZE * sizeof(double *));
	b = (double **)malloc(SIZE * sizeof(double *));
	ab = (double **)malloc(SIZE * sizeof(double *));

	for(int r = 0 ; r < SIZE ; r++)
	{
		a[r] = (double *)malloc(SIZE * sizeof(double));
		b[r] = (double *)malloc(SIZE * sizeof(double));
		ab[r] = (double *)malloc(SIZE * sizeof(double));
	}
	/**/
	
	for(int i = 0 ; i < ITER ; i++)
	{
		// initializing values in a , b:
		for(int r = 0 ; r < SIZE ; r++)
		{
			for(int c = 0 ; c < SIZE ; c++)
			{
				a[r][c] = i + r + 2 * c;
				b[r][c] = i - 2 * c + r;
				ab[r][c] = 0;
			}
		}

		/*for(int r = 0 ; r < SIZE ; r++)
		{
			for(int c = 0 ; c < SIZE ; c++)
			{
				printf("%f " , a[r][c]);
			}
			printf("\n");
		}
		printf("---\n");*/

		/*for(int r = 0 ; r < SIZE ; r++)
		{
			for(int c = 0 ; c < SIZE ; c++)
			{
				printf("%f " , b[r][c]);
			}
			printf("\n");
		}
		printf("---\n");*/

		for(int r = 0 ; r < SIZE ; r++)
		{
			for(int c = 0 ; c < SIZE ; c++)
			{
				for(int k = 0 ; k < SIZE ; k++)
				{
					ab[r][c] += a[r][k] * b[k][c];
				}
			}
		}

		/*for(int r = 0 ; r < SIZE ; r++)
		{
			for(int c = 0 ; c < SIZE ; c++)
			{
				printf("%f " , ab[r][c]);
			}
			printf("\n");
		}
		printf("---\n");*/
		printf("%d\n" , i);
	}

	//////////////////////////
	// comment if on stack: //
	//////////////////////////
	/**/
	for(int r = 0 ; r < SIZE ; r++)
	{
		free(a[r]);
		free(b[r]);
		free(ab[r]);
	}

	free(a);
	free(b);
	free(ab);
	/**/

	return 0;
}
