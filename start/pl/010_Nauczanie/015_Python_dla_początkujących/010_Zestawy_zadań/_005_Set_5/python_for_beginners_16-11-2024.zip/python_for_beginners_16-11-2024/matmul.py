#!/usr/bin/env python3

SIZE = 1024
ITER = 4

a = [[0.0 for _ in range(SIZE)] for _ in range(SIZE)]
b = [[0.0 for _ in range(SIZE)] for _ in range(SIZE)]
ab = [[0.0 for _ in range(SIZE)] for _ in range(SIZE)]

for i in range(ITER):
    for r in range(SIZE):
        for c in range(SIZE):
            a[r][c] = i + r + 2.0 * c
            b[r][c] = i - 2.0 * c + r
            ab[r][c] = 0.0
    for r in range(SIZE):
        for c in range(SIZE):
            for k in range(SIZE):
                ab[r][c] += a[r][k] * b[k][c]
    print(i)
