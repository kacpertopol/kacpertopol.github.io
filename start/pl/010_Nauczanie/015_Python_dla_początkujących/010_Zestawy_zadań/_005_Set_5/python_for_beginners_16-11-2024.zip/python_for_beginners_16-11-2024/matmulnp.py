#!/usr/bin/env python3

import numpy as np

SIZE = 2048
ITER = 8

for i in range(ITER):
    # this actually takes longer since we are allocating new arrays
    a = np.fromfunction(lambda r , c : i + r + 2 * c , (SIZE , SIZE) , dtype = np.double)
    b = np.fromfunction(lambda r , c : i - 2 * c + r , (SIZE , SIZE) , dtype = np.double)

    ab = np.matmul(a , b)
    print(i)

